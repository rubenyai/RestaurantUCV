##*El Restaurant - Proyecto Ingenieria Del Software*##

##
##*Sistemas en Donde la Aplicacion fue Probada*##
Windows 7 / Windows 8 / Windows 8.1 / Ubuntu 15.04

##*Version de JRE y JDK Utilizados*##

JRE & JDK= Java 8 build 51

##
##*Nota Importante*##
En orden de que pueda funcionar el programa, debera ser necesario colocar los archivos ¨billboard.txt¨ y ¨users.txt¨ junto al archivo ¨isucv.restaurant.prototipo.Interfaz.jar¨, ademas de la dependencia AbsoluteLayout.jar en una carpeta llamada lib. todo esto en la raiz de donde se ejecuta el .jar.

Windows: Para correr el programa solo necesitara darle doble click al archivo ¨isucv.restaurant.prototipo.interfaz.jar¨ y se ejecutara el proyecto; o via "cmd java -jar isucv.staurant.prototipo.Interfaz.jar"

Linux- Ubuntu (Cualquier distro que tenga unity y de error con jayatana): "JAVA_TOOL_OPTIONS= java -jar isucv.staurant.prototipo.Interfaz.jar"

Linux*= Via terminal: java -jar isucv.staurant.prototipo.Interfaz.jar"

##
##*Archivo de Credenciales para la Aplicacion*##
En el archivo se definen los nombres de usuario, contrasenas y rol de cada usuario en el sistema.
Los usuarios se describen en una unica linea, con los atributos separados por comas.
Cada linea representa un usuario distinto del sistema.

El formato a utilizar es:


username,password,type

Ejemplo: mesonero1,mesonero2,3


El tipo de usuario es un numero entero positivo descrito como:

	1 = Chef
	2 = Caja
	3 = Mesonero

Los usuarios actualmente creados para la prueba del proyecto son:

	CHEF
	Usuario: chef  Password: angel_lozano
	Usuario: chef1  Password: chef2

	CAJEROS
	Usuario: caja  Password: soyuncajero
	Usuario: caja1  Password: caja2

	MESONEROS
	Usuario: mesonero12  Password: mesa
	Usuario: mesonero1  Password: mesonero2

##
##*Contenido del archivo .rar*##
-Archivo ejecutable para jvm JAR
-Proyecto de Netbeans 8.0.2
-Dependencia AbsoluteLayout.jar


##
##*Creadores del programa*##
Fabian Ramos Rios - CI: 19.274.220


Ruben Maza - CI: 21.534.450


David Alejandro Contreras Silva - CI: 26.725.658
##
##*Dirigido a*##
Cliente Paulo Perez - Ingenieria del Software

##
##*Herramienta usada para la creacion del proyecto*##
- NetBeans IDE 8.0.2
